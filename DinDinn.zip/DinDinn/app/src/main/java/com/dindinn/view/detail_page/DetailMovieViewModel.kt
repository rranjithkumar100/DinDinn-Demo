package com.dindinn.view.detail_page

import com.dindinn.base.MvRxViewModel

class DetailMovieViewModel(val initialState: DetailMovieState) : MvRxViewModel<DetailMovieState>(initialState)