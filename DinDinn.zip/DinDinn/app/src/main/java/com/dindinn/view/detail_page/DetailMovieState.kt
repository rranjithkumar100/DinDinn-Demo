package com.dindinn.view.detail_page

import android.os.Parcelable
import com.airbnb.mvrx.MvRxState
import com.dindinn.data.model.MovieResponse
import kotlinx.android.parcel.Parcelize

@Parcelize
data class DetailMovieArgs(val id: Int, val movie: MovieResponse) : Parcelable

data class DetailMovieState(val id: Int, val movie: MovieResponse): MvRxState {

    /**
     * This secondary constructor will automatically called if your Fragment has
     * a parcelable in its arguments at key [com.airbnb.mvrx.MvRx.KEY_ARG]
     */
    constructor(args: DetailMovieArgs) : this(args.id, args.movie)

}