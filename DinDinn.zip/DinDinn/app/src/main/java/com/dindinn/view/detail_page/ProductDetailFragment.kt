package com.dindinn.view.detail_page

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.airbnb.mvrx.BaseMvRxFragment
import com.airbnb.mvrx.fragmentViewModel
import com.dindinn.R
import com.dindinn.data.api.DummyData
import com.dindinn.utils.AppUtils
import kotlinx.android.synthetic.main.fragment_product_detail.*

class ProductDetailFragment : BaseMvRxFragment()  {

    private val mViewModel: DetailMovieViewModel by fragmentViewModel()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
     return inflater.inflate(R.layout.fragment_product_detail, container, false)
    }

    override fun invalidate() {

        activity?.let { AppUtils.loadImageWithUrl(it,mViewModel.initialState.movie.posterPath,iv_product_detail) }

        tv_title.text = mViewModel.initialState.movie.title
    }
}