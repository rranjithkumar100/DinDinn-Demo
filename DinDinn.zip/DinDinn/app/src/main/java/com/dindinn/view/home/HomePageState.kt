package com.dindinn.view.home

import com.airbnb.mvrx.Async
import com.airbnb.mvrx.MvRxState
import com.airbnb.mvrx.Uninitialized
import com.dindinn.data.model.MovieListResponse
import com.dindinn.data.model.MovieResponse

data class HomePageState(
        /** We use this request to store the list of all food items */
        val movies: List<MovieResponse> = emptyList(),
        /** We use this Async to keep track of the state of the current network request */
        val request: Async<MovieListResponse> = Uninitialized
): MvRxState