package com.dindinn

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import com.dindinn.data.api.ApiService
import com.dindinn.data.api.MovieRepository
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin
import org.koin.dsl.module
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.moshi.MoshiConverterFactory


class App: Application() {

    private val BASE_URL = "http://api.themoviedb.org/3/"
    private val appModule = module {
        single { Moshi.Builder().add(KotlinJsonAdapterFactory()).build() }
        single {
            val retrofit = Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(MoshiConverterFactory.create(get()))
                    .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                    .build()
            retrofit.create(ApiService::class.java)
        }
        factory { MovieRepository(get()) }
    }

    override fun onCreate() {
        super.onCreate()
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true)
        startKoin {
            // Android context
            androidContext(this@App)
            // modules
            modules(appModule)
        }
    }

}