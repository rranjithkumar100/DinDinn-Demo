package com.dindinn.view.home

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.denzcoskun.imageslider.constants.ActionTypes
import com.denzcoskun.imageslider.interfaces.TouchListener
import com.dindinn.R
import com.dindinn.data.api.DummyData
import com.dindinn.utils.Keys
import kotlinx.android.synthetic.main.activity_home.*
import java.util.*

class HomePageActivity : AppCompatActivity() {
    private var mSliderPaused = false
    private val mTitles: MutableList<String> = ArrayList()
    private val mFragments: MutableList<Fragment> = ArrayList()
    private var mTotalCartItems = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        initView()
        setImageSlider()
        setCustomTabView()
    }

    private fun initView() {
        mTitles.clear()
        mTitles.add(DummyData.TYPE_PIZZA)
        mTitles.add(DummyData.TYPE_SUSHI)
        mTitles.add(DummyData.TYPE_DRINKS)
        for (i in 0 until mTitles.size) {
            val fragment = ProductsFragment()
            val args = Bundle()
            args.putString(Keys.KEY_CATEGORY, mTitles[i])
            fragment.arguments = args
            mFragments.add(i, fragment)
        }

        viewpager.adapter = TabBarAdapter(
                supportFragmentManager
                , mTitles, mFragments
        )
        tabs.setupWithViewPager(viewpager)
    }

    private fun setCustomTabView() {
        for (i in 0 until tabs.tabCount) {
            tabs.getTabAt(i)?.setCustomView(R.layout.custom_tab)
            val tabTitle: TextView = tabs.getTabAt(i)?.customView?.findViewById(R.id.tv_tab_title) as TextView
            tabTitle.text = mTitles[i]
        }
    }

    fun addToCart() {
        mTotalCartItems++
        text_count.text = mTotalCartItems.toString()
    }

    private fun setImageSlider() {
        image_slider.setImageList(DummyData.getOfferImages())
        image_slider.setTouchListener(object : TouchListener {
            override fun onTouched(touched: ActionTypes) {
                if (touched == ActionTypes.DOWN) {
                    image_slider.stopSliding()
                    mSliderPaused = true
                } else {
                    if (mSliderPaused) {
                        image_slider.startSliding(1000)
                        mSliderPaused = false
                    }
                }
            }
        })
    }


}