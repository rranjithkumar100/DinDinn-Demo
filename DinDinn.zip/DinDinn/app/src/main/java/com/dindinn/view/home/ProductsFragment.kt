package com.dindinn.view.home

import android.animation.Animator
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import com.airbnb.mvrx.MvRx
import com.airbnb.mvrx.fragmentViewModel
import com.dindinn.R
import com.dindinn.base.BaseFragment
import com.dindinn.base.simpleController
import com.dindinn.data.api.DummyData
import com.dindinn.data.model.MovieResponse
import com.dindinn.utils.CircleAnimationUtil
import com.dindinn.utils.Keys
import com.dindinn.view.detail_page.DetailMovieArgs
import com.dindinn.view.detail_page.ProductDetailFragment
import com.dindinn.view.listrow.ListRowHome
import com.dindinn.view.listrow.listRowHome
import com.dindinn.view.listrow.loadingRow
import kotlinx.android.synthetic.main.fragment_products.*

class ProductsFragment : BaseFragment() {
    private val mViewModel: HomePageViewModel by fragmentViewModel()
    private lateinit var mCategory: String

    override fun resLayout(): Int {
        return R.layout.fragment_products
    }

    override fun epoxyController() = simpleController(mViewModel) {
        it.movies.forEach {
            listRowHome {
                id(it.id)
                val productName = DummyData.getName(mCategory)

                title(productName)

                //imageCover(it.posterPath) //original data
                //dummy image for DinDinn
                val imageURL = DummyData.getImage(mCategory)
                imageCover(imageURL)
                spanSizeOverride { totalSpanCount, _, _ -> totalSpanCount }


                clickListener(object : ListRowHome.AddItemListener {
                    override fun cartClick(imageView: ImageView) {
                        addToCart(imageView)
                    }

                    override fun productClick() {
                        val data = it
                        data.title = productName
                        data.posterPath = imageURL
                        detailsPage(data)
                    }

                })
            }
        }

        loadingRow {
            // Changing the ID will force it to rebind when new data is loaded even if it is
            // still on screen which will ensure that we trigger loading again.
            id("loading${it.movies.size}")
            onBind { _, _, _ -> mViewModel.fetchMovies(mViewModel.popular) }
        }
    }

    private fun detailsPage(data: MovieResponse) {
        val bundle = DetailMovieArgs(data.id, data).let { Bundle().apply { putParcelable(MvRx.KEY_ARG, it) } }
        val fragment = ProductDetailFragment()
        fragment.arguments = bundle
        activity?.supportFragmentManager?.beginTransaction()?.replace(R.id.root_container, fragment)
                ?.addToBackStack(null)
                ?.commit()

    }

    //No live API available for foods.
    private fun addToCart(imageView: ImageView) {

        CircleAnimationUtil().attachActivity(activity).setTargetView(imageView).setMoveDuration(1000).setDestView(fab)
                .setAnimationListener(object : Animator.AnimatorListener {
                    override fun onAnimationRepeat(p0: Animator?) {
                    }

                    override fun onAnimationEnd(p0: Animator?) {
                        (activity as HomePageActivity).addToCart()
                        imageView.clearAnimation()
                    }

                    override fun onAnimationCancel(p0: Animator?) {
                    }

                    override fun onAnimationStart(p0: Animator?) {

                    }

                })
                .startAnimation()


    }


    override fun invalidate() {
        rv_food_items.requestModelBuild()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initView()
        subscribeData()
    }

    private fun subscribeData() {
        mViewModel.asyncSubscribe(HomePageState::request, onFail = {
            mViewModel.fetchMovies(mViewModel.popular)
        }, onSuccess = {
            invalidate()
        })
    }

    private fun initView() {
        if (arguments != null)
            mCategory = arguments!!.getString(Keys.KEY_CATEGORY, DummyData.TYPE_PIZZA)
        rv_food_items.setController(epoxyController)
    }
}