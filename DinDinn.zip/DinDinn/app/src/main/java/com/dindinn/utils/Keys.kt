package com.dindinn.utils

object Keys {
    val KEY_CATEGORY = "category"
}