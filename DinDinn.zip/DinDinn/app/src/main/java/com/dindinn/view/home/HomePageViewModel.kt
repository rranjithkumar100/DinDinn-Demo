package com.dindinn.view.home

import com.airbnb.mvrx.*
import com.dindinn.base.MvRxViewModel
import com.dindinn.data.api.MovieRepository
import org.koin.android.ext.android.inject

class HomePageViewModel(initialState: HomePageState, private val movieRepository: MovieRepository
): MvRxViewModel<HomePageState>(initialState) {

    private var currentPage = 0
    private val maxMovieOnPage = 80

     val popular = "popular"

    init {
        fetchMovies(popular)
    }

    fun fetchMovies(category: String) = withState { state ->
        if (state.request is Loading) return@withState
        if (state.movies.size < maxMovieOnPage) {
            currentPage += 1
            movieRepository.getMovies(category = category, page = currentPage)


                    .execute { copy(request = it, movies = movies + (it()?.movies ?: emptyList())) }
        }
    }

    companion object : MvRxViewModelFactory<HomePageViewModel, HomePageState> {
        @JvmStatic override fun create(viewModelContext: ViewModelContext, state: HomePageState): HomePageViewModel {
            val movieRepository: MovieRepository by viewModelContext.activity.inject()
            return HomePageViewModel(state, movieRepository)
        }
    }

}