package com.dindinn.view.listrow

import android.content.Context
import android.util.AttributeSet
import android.widget.FrameLayout
import android.widget.ImageView
import com.airbnb.epoxy.CallbackProp
import com.airbnb.epoxy.ModelProp
import com.airbnb.epoxy.ModelView
import com.airbnb.epoxy.TextProp
import com.dindinn.R
import com.dindinn.data.api.DummyData
import com.dindinn.utils.AppUtils
import kotlinx.android.synthetic.main.list_row_home.view.*

@ModelView(autoLayout = ModelView.Size.MATCH_WIDTH_WRAP_HEIGHT)
class ListRowHome @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {
    init {
        inflate(context, R.layout.list_row_home, this)
    }

    @TextProp
    fun setTitle(title: CharSequence) {
        tv_title.text = title
        tv_desc.text = DummyData.getDescription()
    }




    @ModelProp
    fun setImageCover(url: String) {
        AppUtils.loadImageWithUrl(context,   url, iv_product_image)
    }

     @CallbackProp
    fun setClickListener(clickListener: AddItemListener?) {
        btn_add.setOnClickListener{
            clickListener?.cartClick(iv_product_image)
        }
         iv_product_image.setOnClickListener {
             clickListener?.productClick()
         }
    }

    interface  AddItemListener {
        fun cartClick(imageView: ImageView)
        fun productClick()
    }
}