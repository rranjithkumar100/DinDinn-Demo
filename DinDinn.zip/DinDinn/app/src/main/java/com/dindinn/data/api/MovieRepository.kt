package com.dindinn.data.api

import com.dindinn.data.model.MovieListResponse
import io.reactivex.Observable

class MovieRepository(private val apiService: ApiService) {

    fun getMovies(category: String, page: Int): Observable<MovieListResponse> =
            apiService.getMovies(category, "3b2cf118bd6d5559d7d6f5b52cc0db63", page)

}