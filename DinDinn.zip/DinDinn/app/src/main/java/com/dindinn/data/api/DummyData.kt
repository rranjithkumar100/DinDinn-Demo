package com.dindinn.data.api

import com.denzcoskun.imageslider.models.SlideModel
import java.util.ArrayList

object DummyData {
    private var pizzaImages = mutableListOf<String>()
    private var sushiImages = mutableListOf<String>()
    private var drinksImages = mutableListOf<String>()

    private var pizzaNames = mutableListOf<String>()
    private var sushiNames = mutableListOf<String>()
    private var drinksNames = mutableListOf<String>()

    private var descriptionList = mutableListOf<String>()

    var TYPE_PIZZA ="Pizza"
    var TYPE_SUSHI ="Sushi"
    var TYPE_DRINKS ="Drinks"
    init {
        addPizzas()
        addSushi()
        addDrinks()
        addDescriptions()
    }

    private fun addDescriptions() {
        descriptionList.add("A tart, sharp, and sometimes harsh flavor")
        descriptionList.add("A taste that feels as though it gives off heat. Another word for spicy")
        descriptionList.add("A smooth and rich texture that usually comes from the incorporation of dairy")
        descriptionList.add("A fine, smooth texture characterized by a sleek feel in the mouth")
        descriptionList.add("A viscous, sometimes sticky texture arising from the presence of moisture in a dense solid food")
        descriptionList.add("Food that has been cooked with dry heat in an oven or over a fire. Often results in a browned exterior and crisp coating")
        descriptionList.add("A firm, crisp texture often identified by the sharp, audible noise that the food makes when being eaten")
    }


    private fun addPizzas(){
        pizzaImages.add("https://previews.123rf.com/images/denisenkomax/denisenkomax1503/denisenkomax150300083/37874155-top-view-tasty-italian-pizza-on-dark-background.jpg")
        pizzaImages.add("https://previews.123rf.com/images/karandaev/karandaev1505/karandaev150500822/40196838-italian-pizza-with-pepperoni-tomatoes-olives-and-basil-on-wooden-table-top-view.jpg")
        pizzaImages.add("https://previews.123rf.com/images/belchonock/belchonock1712/belchonock171209037/92483487-pizza-with-cheese-on-wooden-table-background.jpg")
        pizzaImages.add("https://previews.123rf.com/images/fotoatelie/fotoatelie1602/fotoatelie160200055/53192964-cut-into-slices-delicious-fresh-pizza-with-mushrooms-and-pepperoni-on-a-dark-background-top-view-cop.jpg")
        pizzaImages.add("https://previews.123rf.com/images/belchonock/belchonock1502/belchonock150201526/36267111-pizza-with-cheese-on-board-and-wooden-table-background.jpg")
        pizzaImages.add("https://previews.123rf.com/images/belchonock/belchonock1502/belchonock150205623/36694694-pizza-with-cheese-and-pizza-paddle-on-wooden-table-background.jpg")

        pizzaNames.add("New York-Style Pizza")
        pizzaNames.add("California Pizza")
        pizzaNames.add("Veg Margherita Pizza")
        pizzaNames.add("Neapolitan Pizza")
        pizzaNames.add("St. Louis Pizza")
    }

    private fun addSushi(){
        sushiImages.add("https://previews.123rf.com/images/jagcz/jagcz1509/jagcz150900053/45133226-sushi-pieces-served-on-black-stone-with-chopsticks.jpg")
        sushiImages.add("https://previews.123rf.com/images/ryzhkov86/ryzhkov861909/ryzhkov86190900324/130180868-macro-shot-of-tropical-sushi-rolls.jpg")
        sushiImages.add("https://previews.123rf.com/images/kesu87/kesu871710/kesu87171000026/87481780-japanese-sushi-set-on-a-rustic-dark-background-.jpg")
        sushiImages.add("https://previews.123rf.com/images/subbotina/subbotina1804/subbotina180400033/99967504-sushi-rolls-closeup-japanese-food-in-restaurant-roll-with-salmon-eel-vegetables-and-flying-fish-cavi.jpg")
        sushiImages.add("https://previews.123rf.com/images/givaga/givaga1512/givaga151200027/50375559-sushi-and-rolls-in-plate-on-a-black-background.jpg")

        sushiNames.add("Makizushi")
        sushiNames.add("Temaki")
        sushiNames.add("Nigiri")
        sushiNames.add("Sasazushi")
        sushiNames.add("Gunkan Maki")
    }

    private fun addDrinks(){
        drinksImages.add("https://previews.123rf.com/images/merc67/merc671508/merc67150800073/43416057-summer-berries-smoothie-in-mason-jar-on-rustic-wooden-table.jpg")
        drinksImages.add("https://previews.123rf.com/images/bondd/bondd1901/bondd190100409/114971278-fresh-pineapple-juice-or-cocktail-with-pieces-of-fresh-pineapple-ice-decorated-with-mint-on-a-white-.jpg")
        drinksImages.add("https://previews.123rf.com/images/monticello/monticello1908/monticello190800147/130076498-poznan-pol-aug-13-2019-a-bottle-and-a-glass-of-coca-cola-a-carbonated-soft-drink-manufactured-by-the.jpg")
        drinksImages.add("https://previews.123rf.com/images/fahrwasser/fahrwasser1502/fahrwasser150200150/36801127-watermelon-drink-in-glasses.jpg")
        drinksImages.add("https://previews.123rf.com/images/lilechka75/lilechka751506/lilechka75150600065/41225543-citrus-fizz-with-rosemary-in-a-bottle-.jpg")
        drinksImages.add("https://previews.123rf.com/images/fadhliadnan/fadhliadnan2006/fadhliadnan200603790/150569608-a-7up-can-against-isolated-black-background-a-tasty-fruits-flavour-carbonated-drink.jpg")

    drinksNames.add("Fresh Mango Juice")
    drinksNames.add("Apple Juice")
    drinksNames.add("Pepsi")
    drinksNames.add("Coke")
    drinksNames.add("Fresh Lemon with Soda")
    drinksNames.add("Orange Juice")
    }

    fun getOfferImages(): MutableList<SlideModel>{
        val imageList = ArrayList<SlideModel>() // Create image list
        imageList.add(SlideModel("https://previews.123rf.com/images/zoaarts/zoaarts1901/zoaarts190100021/115660329-vector-illustration-super-sale-banner-template-design-big-sales-special-offer-end-of-season-party-ba.jpg"))
        imageList.add(SlideModel("https://previews.123rf.com/images/alegretgrafic/alegretgrafic1512/alegretgrafic151200523/49486459-special-offer-50-off-round-sticker.jpg"))
        imageList.add(SlideModel("https://i.imgur.com/z1mIF5l.jpg"))
        imageList.add(SlideModel("http://www.dealnloot.com/wp-content/uploads/2017/01/Box8-First-Order-Free-Offer.jpg"))
        return  imageList
    }
    fun getImage(type: String):String{
        when(type) {
            TYPE_PIZZA ->  return pizzaImages.random()
            TYPE_SUSHI ->  return sushiImages.random()
            TYPE_DRINKS ->  return drinksImages.random()

        }
        return pizzaImages.random()

    }
    fun getName(type: String):String{
        when(type) {
            TYPE_PIZZA ->  return pizzaNames.random()
            TYPE_SUSHI ->  return sushiNames.random()
            TYPE_DRINKS ->  return drinksNames.random()

        }
        return pizzaImages.random()

    }

    fun getDescription():String{
        return descriptionList.random()
    }


}